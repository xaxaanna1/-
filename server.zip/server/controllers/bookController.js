const {bookTable} = require('../migrations/20240513065044_user_table');
const ApiError = require('../error/ApiError');


class BookController {
  //добавление товара - функция для админки
  async create(req, res, next) {
    try {
      // Добавление данных для создания карточки товара
      const {name,date,time,persons,phoneNumber,wishes} = req.body;

      // Создание карточки
      const booking = await bookTable.create({name,date,time,persons,phoneNumber,wishes});

      return res.json(booking);
    } catch (e) {
      return next(ApiError.badRequest(e.message));
    }
  }

  async getBooks(req, res, next) {
    try {
      const allBooks = await bookTable.findAll();

      if(!allBooks) return [];

      return res.json(allBooks);
    } catch (e) {
      return next(ApiError.badRequest(e.message));
    }
  }
  
}

module.exports = new BookController();