const uuid = require('uuid');
const ApiError = require('../error/ApiError');
const {BasketGood,Basket,Good,Orders,OrdersGoods,UserAddress,UserInformation, OrdersInformation, preOrders} = require('../migrations/20240513065044_user_table');




class PaymentController {
    
  async makeOrderWithPayment(req, res, next) {
    const userId = req.user.id;

    try {
        const myBasket = await Basket.findOne({ where: { userId } });
        
        if (!myBasket) {
            return next(ApiError.badRequest("Basket not found"));
        }

        const basketId = myBasket.id;

        const getGood = await BasketGood.findAll({
            where: { basketId },
            order: [['createdAt', 'ASC']]
        });

        const goodIds = getGood.map(good => good.goodId);
        const getGoodFeature = await Good.findAll({
            where: {
                id: goodIds
            }
        });

        const userCart = getGood.map(goodInformation => {
            const matchingItem = getGoodFeature.find(goodFeature => goodFeature.id === goodInformation.goodId);
            if (matchingItem) {
                return {
                    id: goodInformation.id,
                    goodId: goodInformation.goodId,
                    count: goodInformation.count,
                    price: matchingItem.price,
                };
            }
        }).filter(item => item !== undefined);

        const totalCartPrice = userCart.reduce((acc, item) => acc + parseInt(item.price) * item.count, 0);

        const userFutureOrder = await Orders.create({
            userId: userId,
            price: totalCartPrice,
            status: "pending"
        });

        const [orderAddress, orderInformation] = await Promise.all([
            UserAddress.findOne({ where: { userId: userId } }),
            UserInformation.findOne({ where: { userId: userId } })
        ]);

        await OrdersInformation.create({
            name: orderInformation.name,
            surname: orderInformation.surname,
            patronymic: orderInformation.patronymic,
            phone: orderInformation.phone,
            city: orderAddress.city,
            street: orderAddress.street,
            region: orderAddress.region,
            index: orderAddress.index,
            orderId: userFutureOrder.id
        });

        const newOrdersPromises = getGood.map(async (basketGood) => {
            const newOrder = {
                goodId: basketGood.goodId,
                count: basketGood.count,
                orderId: userFutureOrder.id
            };

            await OrdersGoods.create(newOrder);
            await BasketGood.destroy({ where: { id: basketGood.id } });
        });

        await Promise.all(newOrdersPromises);

        return res.json(userFutureOrder);
    } catch (error) {
        return next(ApiError.badRequest("Error creating order"));
    }
}

async getAllOrders(req, res, next) {
  try {
    // Получаем все заказы, отсортированные по дате создания в порядке убывания
    const orders = await Orders.findAll({
      order: [['createdAt', 'DESC']],
    });

    // Форматируем заказы
    const formattedOrders = await Promise.all(
      orders.map(async (order) => {
        const orderId = order.id;
        const status = order.status;
        const amount = order.price;

        // Получаем все товары для текущего заказа
        const orderGoods = await OrdersGoods.findAll({
          where: { orderId },
        });

        // Получаем информацию о заказе
        const orderInformation = await OrdersInformation.findOne({
          where: { orderId },
        });

        // Проверка наличия информации о заказе
        if (!orderInformation) {
          throw new Error(`Order information not found for order ID ${orderId}`);
        }

        // Форматируем товары в заказе
        const formattedGoods = await Promise.all(
          orderGoods.map(async (orderGood) => {
            const good = await Good.findOne({ where: { id: orderGood.goodId } });

            // Проверка наличия товара
            if (!good) {
              throw new Error(`Good not found for good ID ${orderGood.goodId}`);
            }

            return {
              name: good.name,
              quantity: orderGood.count,
            };
          })
        );

        // Форматируем заказ
        const formattedOrder = {
          id: orderId,
          status: status,
          amount: amount,
          products: formattedGoods,
          customer: {
            firstName: orderInformation.name,
            lastName: orderInformation.surname,
            middleName: orderInformation.patronymic,
            phone: orderInformation.phone,
            city: orderInformation.city,
            street: orderInformation.street,
            region: orderInformation.region,
            zip: orderInformation.index,
            date: order.createdAt.toISOString().split('T')[0], // Преобразуем дату в формат 'гггг-мм-дд'
          },
        };

        return formattedOrder;
      })
    );

    // Возвращаем отформатированные заказы
    return res.json(formattedOrders);
  } catch (error) {
    console.error('Error fetching orders:', error); // Логируем ошибку
    return next(ApiError.badRequest(`Ошибка при получении заказов: ${error.message}`));
  }
}


  
}
module.exports = new PaymentController();