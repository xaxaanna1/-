const ApiError = require('../error/ApiError');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const {User,Basket,UserInformation,UserAddress} = require('../migrations/20240513065044_user_table');
const {sendEmail} = require('./emailService');

//функция по генерации токена
const generateJwt = (id, email, name) => {

    return jwt.sign({
            id,
            email,
            name
        },
        process.env.JWT_SECRET, {
            expiresIn: process.env.EXPIRE_JWT
        });
}


class UserController {
    //регистрация
    async registration(req, res, next) {

        const {name,email,password} = req.body;
        //условие на проверку данных и вывод ошибки
        if (!name || !email || !password) {
            return next(ApiError.badRequest('Некоректный E-mail или Пароль'))
        }
        //проверка существует ли пользователь или нет
        const candidate = await User.findOne({
            where: {
                email
            }
        });
        //выброс ошибки
        if (candidate) {
            return next(ApiError.badRequest('Пользователь с таким E-mail уже существует'))
        }
        //хеширование пароля пользователя
        const hashPassword = await bcrypt.hash(password, 5);

        if (hashPassword) {
            const user = await User.create({
                email,
                password: hashPassword,
                name: name
            });
            const basket = await Basket.create({userId: user.id});
            const userInformation = await UserInformation.create({userId:user.id,email:user.email});
            const userAddress = await UserAddress.create({userId:user.id});
            //генерация токена с данными пользователя
            const token = generateJwt(user.id, user.email, user.name);
            //тут указать текст письма и заголовок
            await sendEmail(email, 'Регистрация', 'Вы успешно зарегистрированы!');

            return res.json(token);

        } else {
            return next(ApiError.badRequest('Ошибка регистрации'))
        }

    }
    //авторизация
    async login(req, res, next) {
        try {
            const { email, password } = req.body;
    
            // Логируем входящие данные
            const user = await User.findOne({ where: { email } });
    
            // Логируем результат запроса к базе данных
            if (!user) {
                console.log('Пользователь не найден');
                return next(ApiError.internal('Пользователь не найден'));
            }
    
            // Логируем сравнение паролей
            let comparePassword = bcrypt.compareSync(password, user.password);
            if (!comparePassword) {
                console.log('Неверный пароль');
                return next(ApiError.internal('Неверный пароль'));
            }
    
            // Генерация токена
            const token = generateJwt(user.id, user.email, user.roles);
            // Отправка email (можно временно отключить для проверки)
            await sendEmail(email, 'Вход в аккаунт', 'Вы успешно авторизовались!');
            
            return res.json({ token });
        } catch (error) {
            console.error('Ошибка при входе:', error);
            return next(ApiError.internal('Не удалось войти в аккаунт'));
        }

    }
    //проверка авторизации
    async checkAuthorization(req, res, next) {

        const token = generateJwt(req.user.id, req.user.email);

        return res.json(token);

    }
    //поиск по почте
    async findByEmail(req, res, next) {
        const { email } = req.body;
        
        try {
            const user = await User.findOne({ where: { email } });
            if (!user) {
                return next(ApiError.badRequest('Пользователь не найден'));
            }
            return res.json(user);
        } catch (error) {
            console.error(error);
            return next(ApiError.internal('Ошибка поиска пользователя'));
        }
    }
    // Обновление данных пользователя
    async update(req, res, next) {
        const userId = req.user.id; 
        const { name, email, password } = req.body;
    
        try {
            // Поиск пользователя по id
            const user = await User.findOne({ where: { id: userId } });
    
            if (!user) {
                return next(ApiError.badRequest('Пользователь не найден'));
            }
            // Хеширование пароля, если он предоставлен
            let updatedFields = { name, email };
            if (password) {
                const hashPassword = await bcrypt.hash(password, 5);
                updatedFields.password = hashPassword;
            }
            // Обновление пользователя
            await user.update(updatedFields);
    
            return res.json(user);
        } catch (error) {
            console.error(error);
            return next(ApiError.internal('Ошибка обновления пользователя'));
        }
    }
    async getAllUsers(req, res, next) {
        try {
          const allUsers = await User.findAll({
            order: [['id', 'ASC']]
          });
      
          const userInfoArray = [];
      
          for (let user of allUsers) {
            const userInfo = await UserInformation.findOne({ where: { userId: user.id } });
      
            const userObject = {
              id: user.id,
              name: userInfo.name,
              surname: userInfo.surname,
              patronymic: userInfo.patronymic,
              phone: userInfo.phone,
              email: user.email
            };
      
            userInfoArray.push(userObject);
          }
      
          return res.json(userInfoArray);
        } catch (error) {
          return next(ApiError.badRequest(error));
        }
      }
}

module.exports = new UserController();