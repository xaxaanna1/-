const sequelize = require('../db');
const {
  DataTypes
} = require('sequelize');

const User = sequelize.define('user', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  },
});
const Good = sequelize.define('good', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
  price: {
    type: DataTypes.STRING,
    allowNull: false
  },
  img: {
    type: DataTypes.ARRAY(DataTypes.STRING),
    allowNull: false
  },
  description: {
    type: DataTypes.STRING,
    allowNull: false
  },
});
const Type = sequelize.define('type', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false
  },
});
const bookTable = sequelize.define('bookTable', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  date: {
    type: DataTypes.STRING,
    allowNull: false
  },
  time: {
    type: DataTypes.STRING,
    allowNull: false
  },
  persons: {
    type: DataTypes.STRING,
    allowNull: false
  },
  phoneNumber: {
    type: DataTypes.STRING,
    allowNull: false
  },
  wishes: {
    type: DataTypes.STRING,
  },
})
const Basket = sequelize.define('basket', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
});
const BasketGood = sequelize.define('basket_good', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  count: {
    type: DataTypes.INTEGER,
    defaultValue: 1
  }
});
const UserInformation = sequelize.define('user_information', {
  id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
  },
  name: {
      type: DataTypes.STRING,
  },
  surname: {
      type: DataTypes.STRING,
  },
  patronymic: {
      type: DataTypes.STRING,
  },
  phone: {
      type: DataTypes.STRING,
  },
  email: {
      type: DataTypes.STRING,
      unique: true
  },
});

const UserAddress = sequelize.define('address_information', {
  city: {
      type: DataTypes.STRING,
  },
  street: {
      type: DataTypes.STRING,
  },
  region: {
      type: DataTypes.STRING,
  },
  index: {
      type: DataTypes.INTEGER,
  }
});

const OrdersGoods = sequelize.define('orders_good', {
  id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
  },
  goodId: {
      type: DataTypes.INTEGER,
      allowNull: false
  },
  count: {
      type: DataTypes.INTEGER,
      defaultValue: 1
  },
});

const OrdersInformation = sequelize.define('orders_information', {
  id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
  },
  name: {
      type: DataTypes.STRING,
  },
  surname: {
      type: DataTypes.STRING,
  },
  patronymic: {
      type: DataTypes.STRING,
  },
  phone: {
      type: DataTypes.STRING,
  },
  city: {
      type: DataTypes.STRING,
  },
  street: {
      type: DataTypes.STRING,
  },
  region: {
      type: DataTypes.STRING,
  },
  index: {
      type: DataTypes.INTEGER,
  }
})

const Orders = sequelize.define('orders', {
  id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
  },
  status: {
      type: DataTypes.STRING,
      allowNull: true,
  },
  price: {
      type: DataTypes.INTEGER,
      defaultValue: 0
  },
});


User.hasOne(Basket);
Basket.belongsTo(User);

Basket.hasMany(BasketGood);
BasketGood.belongsTo(Basket);

Type.hasMany(Good);
Good.belongsTo(Type);

Good.hasMany(BasketGood);
BasketGood.belongsTo(Good);

User.hasOne(UserInformation);
UserInformation.belongsTo(User);

User.hasOne(UserAddress);
UserAddress.belongsTo(User);

User.hasMany(Orders);
Orders.belongsTo(User);

Orders.hasMany(OrdersGoods);
OrdersGoods.belongsTo(Orders);

Orders.hasMany(OrdersInformation);
OrdersInformation.belongsTo(Orders);

module.exports = {
  User,
  Good,
  Type,
  bookTable,
  Basket,
  BasketGood,
  UserInformation,
  UserAddress,
  OrdersGoods,
  OrdersInformation,
  Orders,
}