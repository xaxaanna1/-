const Router = require('express');
const router = new Router();
const AuthMiddleware = require('../middleware/authMiddleWare');
const paymentController = require('../controllers/paymentController');


router.post('/payment-order',AuthMiddleware,paymentController.makeOrderWithPayment);
router.get('/getAllOrders',paymentController.getAllOrders);



module.exports = router;