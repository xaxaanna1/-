const Router = require('express');
const userRouter = require('./userRouter');
const goodRouter = require('./goodRouter');
const typeRouter = require('./typeRouter');
const bookRouter = require('./bookRouter');
const basketRouter = require('./basketRouter');
const userInformationRouter = require('./userInformationRouter');
const userAddressRouter = require('./userAddressRouter');
const paymentRouter = require('./paymentRouter');
const router = new Router();


router.use('/user',userRouter);
router.use('/goods',goodRouter);
router.use('/type',typeRouter);
router.use('/book',bookRouter);
router.use('/basket',basketRouter);
router.use('/information',userInformationRouter);
router.use('/address',userAddressRouter);
router.use('/address',userAddressRouter);
router.use('/payment',paymentRouter);





module.exports = router;