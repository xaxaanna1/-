const Router = require('express');
const router = new Router();
const BookController = require('../controllers/bookController');
const authMiddleWare = require('../middleware/authMiddleWare');



router.post('/create' ,BookController.create);
router.get('/getBooks', authMiddleWare,BookController.getBooks);



module.exports = router;
